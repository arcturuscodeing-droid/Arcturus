/**
 * ============================================================
 *  ARCTURUS SMART API ENGINE  —  v2.0
 * ============================================================
 *
 *  What's new in v2.0:
 *
 *  CASTING MODE
 *  ─────────────
 *  When enabled, the engine filters out iframe-only sources and
 *  prioritises only sources that can deliver a direct stream URL
 *  compatible with AirPlay and Chromecast. If none are available
 *  it calls onNoCastSource(fallback) so the UI can notify the user
 *  and offer the fastest non-casting source as a fallback instead.
 *  When disabled, all sources are ranked by quality as normal.
 *
 *  SMART SCREEN-AWARE BLACK BAR CROP
 *  ────────────────────────────────────
 *  v1.0 compared the iframe ratio against a fixed 16:9 target —
 *  which meant it could never detect bars that exist inside the
 *  video itself (the embed player already fills the iframe at 16:9
 *  even when the movie is 2.39:1 with letterbox bars baked in).
 *
 *  v2.0 approach:
 *   1. Detect the real display environment — phone / tablet /
 *      desktop / TV / ultrawide — using screen.width, DPR, and
 *      aspect ratio geometry.
 *   2. For each known content ratio (21:9, 2.39:1, 1.85:1, 4:3…)
 *      calculate what percentage of the iframe height would be
 *      black if that content were letterboxed inside a 16:9 frame.
 *   3. Pick the best-fit content ratio and compute the exact CSS
 *      scale() needed to zoom the iframe until the black bars are
 *      pushed outside the overflow:hidden container.
 *   4. On TV: scale slightly more aggressively to fill edge-to-edge.
 *      On ultrawide: target 21:9 instead of 16:9.
 *      On phone/portrait: skip crop (no bars in portrait content).
 *   5. ResizeObserver + orientationchange re-run the check live,
 *      so rotating a tablet or going fullscreen recalculates instantly.
 *   6. Three checks after load (800ms / 2s / 4s) because some embed
 *      players paint their video content late.
 * ============================================================
 */

const ArcturusEngine = (() => {

    // ── Internal state ────────────────────────────────────────────────────────
    let _rankedSources      = [];
    let _activeIndex        = 0;
    let _qualityData        = {};
    let _contentId          = null;
    let _contentType        = null;
    let _tvParams           = {};
    let _onSourceChange     = null;
    let _onNoCastSource     = null;
    let _preloadIframes     = [];
    let _autoCropEnabled    = true;
    let _castingModeEnabled = false;
    let _resizeObserver     = null;
    let _activePlayerEl     = null;
    let _cropCheckTimers    = [];

    const QUALITY_JSON_URL = './quality-data.json';
    const TEST_TIMEOUT_MS  = 3000;
    const PRELOAD_COUNT    = 3;

    // ── Casting-compatible source list ────────────────────────────────────────
    // These sources are known to support direct HLS/MP4 stream URLs
    // that AirPlay and Chromecast receivers can play natively.
    // Iframe-only sources are NOT in this set.
    const CASTING_SOURCES = new Set([
        'vidfast',      // direct HLS
        'videasy',      // direct HLS
        'pstream',      // direct stream endpoint
        'vidzee',       // direct stream
        'embedsu',      // supports direct URL
        'vidsrcXyz',    // direct stream
        'vidsrcrip',    // direct stream
        'vidsrcsu',     // direct stream
        'vidsrcvip',    // direct stream
        'vidsrccx',     // direct stream
    ]);

    // ── Quality scores (fallback when quality-data.json is unavailable) ───────
    const FALLBACK_QUALITY = {
        'videasy'     : 95,
        'vidfast'     : 95,
        'vidzee'      : 85,
        'pstream'     : 82,
        'embedsu'     : 80,
        'hexa'        : 78,
        'vidlink'     : 75,
        'vidsrcXyz'   : 72,
        'vidsrcrip'   : 70,
        'vidsrcsu'    : 70,
        'vidsrcvip'   : 70,
        'multiembed'  : 68,
        'moviesapi'   : 68,
        'mapple'      : 65,
        'autoembed'   : 65,
        'flicky'      : 62,
        'rive'        : 62,
        'vidora'      : 60,
        'nebula'      : 60,
        'smashystream': 58,
        '2embed'      : 55,
        '123embed'    : 55,
        '111movies'   : 52,
        'spenflix'    : 50,
        'vidify'      : 50,
        'vidsrccx'    : 48,
        'uembed'      : 45,
        'frembed'     : 40,
    };

    // ── Utility ───────────────────────────────────────────────────────────────

    function buildUrl(source, type, params) {
        const tpl = source.urls[type];
        if (!tpl) return null;
        return tpl
            .replace('{id}',      params.id      || '')
            .replace('{season}',  params.season  || 1)
            .replace('{episode}', params.episode || 1);
    }

    function fetchWithTimeout(url, ms) {
        const ctrl  = new AbortController();
        const timer = setTimeout(() => ctrl.abort(), ms);
        return fetch(url, { signal: ctrl.signal, mode: 'no-cors' })
            .then(r  => { clearTimeout(timer); return r; })
            .catch(() => { clearTimeout(timer); return null; });
    }

    async function loadQualityData() {
        try {
            const res = await fetch(QUALITY_JSON_URL);
            if (res.ok) { _qualityData = await res.json(); }
        } catch { /* use fallback */ }
    }

    function qualityScore(id) {
        return (_qualityData[id]?.score) ?? (FALLBACK_QUALITY[id] ?? 40);
    }

    // ── Screen environment detection ──────────────────────────────────────────
    /**
     * Classify the display using physical signals:
     *  - window.screen.width / height  → CSS pixel dimensions of the screen
     *  - devicePixelRatio              → physical pixels per CSS pixel
     *  - Ratio (w/h)                   → landscape shape
     *
     * TV detection: TVs report DPR=1 even at 4K. They're landscape, >= 1280px wide.
     * Ultrawide: ratio > 2.1 (e.g. 3440×1440 = 2.39 ratio).
     * Desktop with high DPR (1.5×, 2×): those are HiDPI monitors, NOT TVs.
     */
    function getScreenProfile() {
        const sw    = window.screen.width  || window.innerWidth;
        const sh    = window.screen.height || window.innerHeight;
        const dpr   = window.devicePixelRatio || 1;
        const ratio = sw / sh;

        // Ultrawide first — ratio > 2.1 at large width (check before TV)
        if (ratio > 2.1 && sw >= 1800) {
            return { type: 'ultrawide', sw, sh, ratio, dpr };
        }
        // TV: >= 1280px, DPR exactly 1 (or very close), 16:9-ish, standard TV width
        const tvWidth = sw <= 1920 || sw === 3840 || sw === 2160;
        if (sw >= 1280 && dpr <= 1.1 && ratio >= 1.6 && ratio <= 2.1 && tvWidth) {
            return { type: 'tv', sw, sh, ratio, dpr };
        }
        // Phone: small or very high DPR
        if (sw <= 480 || (sw * dpr <= 1080 && dpr >= 2)) {
            return { type: 'phone', sw, sh, ratio, dpr };
        }
        // Tablet
        if (sw <= 1024) {
            return { type: 'tablet', sw, sh, ratio, dpr };
        }
        return { type: 'desktop', sw, sh, ratio, dpr };
    }

    // ── Smart black bar crop ──────────────────────────────────────────────────
    /**
     * Common content aspect ratios. Embed players letterbox widescreen content
     * (like 2.39:1 movies) inside a 16:9 iframe. The black bars are baked into
     * the video frame itself — we can't see them from outside the iframe.
     *
     * Strategy: we know embed sources deliver content at these known ratios.
     * We calculate the crop scale for each one against the target ratio,
     * then apply the best fit. The user toggles off if it's wrong.
     *
     * barFraction = 1 - (targetRatio / contentRatio)
     * This is the fraction of height that is black bar (top+bottom combined).
     * Scale = contentRatio / targetRatio to fill the container.
     */
    const CONTENT_RATIOS = [
        { name: '2.39:1 scope',    ratio: 2.390 },  // Most Hollywood movies
        { name: '2.35:1 scope',    ratio: 2.350 },  // Classic scope
        { name: '2.20:1',          ratio: 2.200 },  // 70mm
        { name: '21:9 / 2.33:1',   ratio: 21/9  },  // Modern widescreen
        { name: '1.85:1 flat',     ratio: 1.850 },  // US flat widescreen
        { name: '16:9',            ratio: 16/9  },  // Standard HD — no bars
        { name: '4:3',             ratio: 4/3   },  // Classic TV
    ];

    // The target ratio we want to fill (what the player container is)
    function getTargetRatio(screenProfile) {
        switch (screenProfile.type) {
            case 'ultrawide': return 21 / 9;   // Fill ultrawide with 21:9
            case 'tv':        return 16 / 9;   // TVs are 16:9
            default:          return 16 / 9;   // Everything else
        }
    }

    /**
     * Given a content ratio and target container ratio, calculate:
     * - Whether letterbox bars exist (content wider than container)
     * - The scale factor to zoom the iframe to eliminate the bars
     * - How many pixels of bar we'd be removing
     */
    function calcCrop(contentRatio, targetRatio, containerHeight) {
        if (contentRatio <= targetRatio) return null; // no letterbox bars

        // Black bar height as fraction of container height (top+bottom combined)
        const barFraction = 1 - (targetRatio / contentRatio);
        if (barFraction < 0.03) return null; // < 3% bars — not worth cropping

        // Scale to fill: zoom in so the video height fills the container
        // The black bars get pushed outside the overflow:hidden boundary
        const scale = contentRatio / targetRatio;

        // Absolute pixel height of bars being removed
        const barPx = containerHeight * barFraction / 2;

        return { scale, barFraction, barPx };
    }

    /**
     * Main crop decision function.
     * Returns { shouldCrop, scale, reason } or { shouldCrop: false }
     */
    function computeCrop(playerEl, screenProfile) {
        const rect = playerEl.getBoundingClientRect();
        if (!rect.width || !rect.height) return { shouldCrop: false };

        const targetRatio = getTargetRatio(screenProfile);

        // Portrait phone — no crop needed
        if (screenProfile.type === 'phone' && rect.height > rect.width) {
            return { shouldCrop: false, reason: 'portrait phone — skip' };
        }

        // Try each known content ratio and find the most aggressive
        // crop that still makes visual sense (barFraction 3%–35%)
        let bestCrop = null;
        let bestRatio = null;

        for (const cr of CONTENT_RATIOS) {
            if (cr.ratio <= targetRatio + 0.02) continue; // not wider than container
            const crop = calcCrop(cr.ratio, targetRatio, rect.height);
            if (!crop) continue;
            // Prefer larger bar removal (more impactful) but cap at 35%
            if (crop.barFraction > 0.35) continue;
            if (!bestCrop || crop.barFraction > bestCrop.barFraction) {
                bestCrop  = crop;
                bestRatio = cr;
            }
        }

        if (!bestCrop) return { shouldCrop: false, reason: 'no bars detected' };

        // Extra nudge on TV to fill edge-to-edge
        let finalScale = bestCrop.scale;
        if (screenProfile.type === 'tv') finalScale *= 1.015;

        // Hard cap — never scale more than 40% to preserve quality
        finalScale = Math.min(finalScale, 1.40);

        return {
            shouldCrop:   true,
            scale:        finalScale,
            contentRatio: bestRatio.name,
            barPercent:   Math.round(bestCrop.barFraction * 100),
            screenType:   screenProfile.type,
        };
    }

    function applyCrop(playerEl, cropResult) {
        const iframe = playerEl.querySelector('iframe');
        if (!iframe) return;

        if (cropResult.shouldCrop && _autoCropEnabled) {
            const s = cropResult.scale.toFixed(4);
            iframe.style.transform       = `scale(${s})`;
            iframe.style.transformOrigin = 'center center';
            playerEl.style.overflow      = 'hidden';
            console.log(
                `[Arcturus] Crop: scale(${s}) | content: ${cropResult.contentRatio}` +
                ` | bars: ~${cropResult.barPercent}% | screen: ${cropResult.screenType}`
            );
        } else {
            iframe.style.transform       = '';
            iframe.style.transformOrigin = '';
            playerEl.style.overflow      = '';
            if (!cropResult.shouldCrop) {
                console.log(`[Arcturus] No crop needed — ${cropResult.reason || 'clean fit'}`);
            }
        }
    }

    function runCropCheck(playerEl) {
        const screen = getScreenProfile();
        const result = computeCrop(playerEl, screen);
        applyCrop(playerEl, result);
    }

    /**
     * Schedule multiple crop checks after a source loads.
     * Some embed players paint video content late (lazy loading, ads, etc.)
     * so we check at 1s, 2.5s, and 5s.
     */
    function scheduleCropChecks(playerEl) {
        _activePlayerEl = playerEl;
        _cropCheckTimers.forEach(t => clearTimeout(t));
        _cropCheckTimers = [];
        [1000, 2500, 5000].forEach(delay => {
            _cropCheckTimers.push(setTimeout(() => {
                if (_autoCropEnabled && playerEl.querySelector('iframe')) {
                    runCropCheck(playerEl);
                }
            }, delay));
        });
    }

    /**
     * Attach a ResizeObserver so crop recalculates when:
     *  - Window is resized
     *  - Browser goes fullscreen
     *  - Device is rotated
     */
    function attachCropObserver(playerEl) {
        if (_resizeObserver) _resizeObserver.disconnect();

        if (window.ResizeObserver) {
            _resizeObserver = new ResizeObserver(() => {
                if (_autoCropEnabled && playerEl.querySelector('iframe')) {
                    runCropCheck(playerEl);
                }
            });
            _resizeObserver.observe(playerEl);
        }

        // Orientation change on mobile/tablet
        window.addEventListener('orientationchange', () => {
            setTimeout(() => {
                if (_autoCropEnabled && playerEl && playerEl.querySelector('iframe')) {
                    runCropCheck(playerEl);
                }
            }, 400);
        }, { once: false });
    }

    // ── Source testing ────────────────────────────────────────────────────────

    async function testAllSources(sources, type, params) {
        console.log(`[Arcturus] Testing ${sources.length} sources simultaneously…`);

        const tests = sources
            .filter(s => !s.isFrench)
            .map(async source => {
                const url = buildUrl(source, type, params);
                if (!url) return null;
                const res = await fetchWithTimeout(url, TEST_TIMEOUT_MS);
                if (res !== null) {
                    return {
                        source,
                        url,
                        responded:         true,
                        castCompatible:    CASTING_SOURCES.has(source.id),
                    };
                }
                return null;
            });

        const live = (await Promise.all(tests)).filter(Boolean);
        console.log(`[Arcturus] ${live.length}/${sources.filter(s=>!s.isFrench).length} sources responded`);
        return live;
    }

    function rankSources(liveResults) {
        return liveResults
            .map(r => ({
                ...r,
                score:    qualityScore(r.source.id),
                verified: !!_qualityData[r.source.id],
            }))
            .sort((a, b) => b.score - a.score);
    }

    // ── Preloading ────────────────────────────────────────────────────────────

    function clearPreloadIframes() {
        _preloadIframes.forEach(f => f.parentNode && f.parentNode.removeChild(f));
        _preloadIframes = [];
    }

    function preloadTopSources(ranked) {
        clearPreloadIframes();
        ranked.slice(0, PRELOAD_COUNT).forEach((r, i) => {
            if (i === 0) return; // #1 loads in the real player
            const iframe = document.createElement('iframe');
            iframe.src = r.url;
            iframe.style.cssText = 'position:fixed;top:-9999px;left:-9999px;width:1280px;height:720px;opacity:0;pointer-events:none;border:none;';
            iframe.setAttribute('aria-hidden', 'true');
            iframe.setAttribute('data-arcturus-preload', r.source.id);
            document.body.appendChild(iframe);
            _preloadIframes.push(iframe);
            console.log(`[Arcturus] Preloading #${i + 1}: ${r.source.id}`);
        });
    }

    // ── Failover ──────────────────────────────────────────────────────────────

    function doFailover(playerEl) {
        // In casting mode skip ahead past non-cast sources
        if (_castingModeEnabled) {
            let next = _activeIndex + 1;
            while (next < _rankedSources.length && !_rankedSources[next].castCompatible) {
                next++;
            }
            if (next < _rankedSources.length) {
                _activeIndex = next;
            } else if (_activeIndex < _rankedSources.length - 1) {
                _activeIndex++; // no cast source — use next best
            } else {
                console.warn('[Arcturus] All sources exhausted.');
                return;
            }
        } else {
            if (_activeIndex >= _rankedSources.length - 1) {
                console.warn('[Arcturus] All sources exhausted.');
                return;
            }
            _activeIndex++;
        }

        const next = _rankedSources[_activeIndex];
        console.log(`[Arcturus] Failover → ${next.source.id} (score: ${next.score})`);
        loadSource(next.url, playerEl);
        if (_onSourceChange) _onSourceChange(next.url, 'arcturusapi');
    }

    function loadSource(url, playerEl) {
        playerEl.innerHTML = '';
        const iframe = document.createElement('iframe');
        iframe.src             = url;
        iframe.className       = 'absolute top-0 left-0 w-full h-full';
        iframe.frameBorder     = '0';
        iframe.scrolling       = 'no';
        iframe.allowFullscreen = true;

        iframe.addEventListener('load', () => {
            console.log('[Arcturus] Source loaded ✓');
            scheduleCropChecks(playerEl);
            attachCropObserver(playerEl);
        });
        iframe.addEventListener('error', () => {
            console.warn('[Arcturus] Source error — failing over…');
            doFailover(playerEl);
        });

        playerEl.appendChild(iframe);
    }

    // ── Casting helpers ───────────────────────────────────────────────────────

    /**
     * Filter ranked list to casting-compatible only.
     * Returns the filtered list, or null if none available.
     */
    function getCastRanked() {
        return _rankedSources.filter(r => r.castCompatible);
    }

    // ── Public API ────────────────────────────────────────────────────────────

    return {

        /**
         * Initialise the engine. Call when the detail page loads.
         *
         * @param {Object}   opts.sources        ARCTURUS_SOURCES array
         * @param {string}   opts.contentId      TMDB id
         * @param {string}   opts.contentType    'movie' | 'tv'
         * @param {Object}   opts.tvParams       { season, episode }
         * @param {boolean}  opts.castingMode    prefer cast-compatible sources
         * @param {Function} opts.onReady        called with ranked[] when done
         * @param {Function} opts.onNoCastSource called with best fallback when
         *                                       casting mode on but no cast source found
         */
        async init({ sources, contentId, contentType, tvParams = {}, castingMode = false, onReady, onNoCastSource }) {
            console.log('[Arcturus] Engine v2.0 initialising…');
            _contentId          = contentId;
            _contentType        = contentType;
            _tvParams           = tvParams;
            _castingModeEnabled = castingMode;
            _onNoCastSource     = onNoCastSource || null;

            const params = contentType === 'tv'
                ? { id: contentId, ...tvParams }
                : { id: contentId };

            await loadQualityData();

            const live = await testAllSources(sources, contentType, params);
            let ranked = rankSources(live);

            if (_castingModeEnabled) {
                const castRanked = ranked.filter(r => r.castCompatible);
                if (castRanked.length > 0) {
                    console.log(`[Arcturus] Cast mode — ${castRanked.length} compatible sources available`);
                    // Put casting sources first, others after as fallbacks
                    const nonCast = ranked.filter(r => !r.castCompatible);
                    ranked = [...castRanked, ...nonCast];
                } else {
                    console.warn('[Arcturus] Cast mode — no compatible sources found');
                    if (_onNoCastSource) _onNoCastSource(ranked[0] || null);
                }
            }

            _rankedSources = ranked;

            if (_rankedSources.length === 0) {
                console.warn('[Arcturus] No sources available.');
                if (onReady) onReady([]);
                return;
            }

            console.log('[Arcturus] Top sources:');
            _rankedSources.slice(0, 5).forEach((r, i) =>
                console.log(`  #${i+1} ${r.source.id.padEnd(14)} score:${r.score}${r.castCompatible?' 📡':''}${r.verified?' ✓':''}`)
            );

            preloadTopSources(_rankedSources);
            if (onReady) onReady(_rankedSources);
        },

        /**
         * Load the best source. Call from inside onReady callback.
         */
        play(playerEl, onSourceChange) {
            _activeIndex    = 0;
            _onSourceChange = onSourceChange;

            if (_rankedSources.length === 0) {
                playerEl.innerHTML = `<div class="absolute inset-0 flex items-center justify-center bg-gray-900 text-white text-center p-4">Arcturus API: No sources available right now.</div>`;
                return;
            }

            const best = _rankedSources[0];
            console.log(`[Arcturus] Playing: ${best.source.id} (score:${best.score}${best.castCompatible?' 📡':''})`);
            loadSource(best.url, playerEl);
        },

        /** Failover to next ranked source */
        failover(playerEl) {
            doFailover(playerEl);
        },

        /**
         * Enable or disable casting mode.
         * Immediately reloads the player with the best cast-compatible source.
         */
        setCastingMode(enabled, playerEl, onNoCastSource) {
            _castingModeEnabled = enabled;
            if (onNoCastSource) _onNoCastSource = onNoCastSource;
            console.log(`[Arcturus] Casting mode: ${enabled ? 'ON 📡' : 'OFF'}`);

            if (!enabled || !playerEl) return;

            const castSources = getCastRanked();
            if (castSources.length > 0) {
                // Re-rank: cast sources first
                const nonCast = _rankedSources.filter(r => !r.castCompatible);
                _rankedSources = [...castSources, ...nonCast];
                _activeIndex   = 0;
                loadSource(_rankedSources[0].url, playerEl);
            } else {
                console.warn('[Arcturus] No cast sources in current pool');
                if (_onNoCastSource) _onNoCastSource(_rankedSources[0] || null);
            }
        },

        /**
         * Toggle auto crop. Immediately re-runs detection.
         */
        setAutoCrop(enabled, playerEl) {
            _autoCropEnabled = enabled;
            if (!playerEl) return;
            if (enabled) {
                runCropCheck(playerEl);
            } else {
                const iframe = playerEl.querySelector('iframe');
                if (iframe) { iframe.style.transform = ''; iframe.style.transformOrigin = ''; }
                playerEl.style.overflow = '';
            }
        },

        /** Force a fresh crop check (e.g. after fullscreen toggle) */
        recheckCrop(playerEl) {
            if (_autoCropEnabled && playerEl) runCropCheck(playerEl);
        },

        isCastingModeEnabled() { return _castingModeEnabled; },
        isAutoCropEnabled()    { return _autoCropEnabled; },
        getRankedSources()     { return _rankedSources; },
        getActiveSource()      { return _rankedSources[_activeIndex] || null; },
        getScreenProfile()     { return getScreenProfile(); },

        async refresh({ contentId, contentType, tvParams, sources, castingMode, onReady, onNoCastSource }) {
            clearPreloadIframes();
            _rankedSources = [];
            _activeIndex   = 0;
            await this.init({ sources, contentId, contentType, tvParams, castingMode, onReady, onNoCastSource });
        },

        destroy() {
            clearPreloadIframes();
            _cropCheckTimers.forEach(t => clearTimeout(t));
            if (_resizeObserver) _resizeObserver.disconnect();
        }
    };

})();
