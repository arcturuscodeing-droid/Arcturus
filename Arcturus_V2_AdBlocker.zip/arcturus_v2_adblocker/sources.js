/**
 * ─────────────────────────────────────────────────────────────
 *  ARCTURUS SOURCE REGISTRY
 *  All sources are tested silently behind Arcturus API.
 *  Only "Arcturus API" is shown in the UI.
 *  Do not add or remove sources without also updating quality-data.json.
 * ─────────────────────────────────────────────────────────────
 */

// The engine tests all sources in ARCTURUS_SOURCES simultaneously.
// The UI only ever shows the single entry in availableSources.
const ARCTURUS_SOURCES = [
    {
        id: 'videasy',
        name: 'VidEasy (4K)',
        isFrench: false,
        urls: {
            movie: 'https://player.videasy.net/movie/{id}?color=8834ec',
            tv:    'https://player.videasy.net/tv/{id}/{season}/{episode}?color=8834ec'
        }
    },
    {
        id: 'vidfast',
        name: 'VidFast (4K)',
        isFrench: false,
        urls: {
            movie: 'https://vidfast.pro/movie/{id}',
            tv:    'https://vidfast.pro/tv/{id}/{season}/{episode}'
        }
    },
    {
        id: 'vidzee',
        name: 'VidZee',
        isFrench: false,
        urls: {
            movie: 'https://player.vidzee.wtf/embed/movie/{id}',
            tv:    'https://player.vidzee.wtf/embed/tv/{id}/{season}/{episode}'
        }
    },
    {
        id: 'pstream',
        name: 'P-Stream',
        isFrench: false,
        urls: {
            movie: 'https://iframe.pstream.mov/media/tmdb-movie-{id}',
            tv:    'https://iframe.pstream.mov/media/tmdb-tv-{id}/{season}/{episode}'
        }
    },
    {
        id: 'embedsu',
        name: 'EmbedSU',
        isFrench: false,
        urls: {
            movie: 'https://embed.su/embed/movie/{id}',
            tv:    'https://embed.su/embed/tv/{id}/{season}/{episode}'
        }
    },
    {
        id: 'hexa',
        name: 'Hexa',
        isFrench: false,
        urls: {
            movie: 'https://hexa.watch/watch/movie/{id}',
            tv:    'https://hexa.watch/watch/tv/{id}/{season}/{episode}'
        }
    },
    {
        id: 'vidlink',
        name: 'VidLink',
        isFrench: false,
        urls: {
            movie: 'https://vidlink.pro/movie/{id}',
            tv:    'https://vidlink.pro/tv/{id}/{season}/{episode}'
        }
    },
    {
        id: 'vidsrcXyz',
        name: 'VidSrcXyz',
        isFrench: false,
        urls: {
            movie: 'https://vidsrc.xyz/embed/movie/{id}',
            tv:    'https://vidsrc.xyz/embed/tv/{id}/{season}/{episode}'
        }
    },
    {
        id: 'vidsrcrip',
        name: 'VidSrcRIP',
        isFrench: false,
        urls: {
            movie: 'https://vidsrc.rip/embed/movie/{id}',
            tv:    'https://vidsrc.rip/embed/tv/{id}/{season}/{episode}'
        }
    },
    {
        id: 'vidsrcsu',
        name: 'VidSrcSU',
        isFrench: false,
        urls: {
            movie: 'https://vidsrc.su/embed/movie/{id}',
            tv:    'https://vidsrc.su/embed/tv/{id}/{season}/{episode}'
        }
    },
    {
        id: 'vidsrcvip',
        name: 'VidSrcVIP',
        isFrench: false,
        urls: {
            movie: 'https://vidsrc.vip/embed/movie/{id}',
            tv:    'https://vidsrc.vip/embed/tv/{id}/{season}/{episode}'
        }
    },
    {
        id: 'multiembed',
        name: 'MultiEmbed',
        isFrench: false,
        urls: {
            movie: 'https://multiembed.mov/?video_id={id}&tmdb=1',
            tv:    'https://multiembed.mov/?video_id={id}&tmdb=1&s={season}&e={episode}'
        }
    },
    {
        id: 'moviesapi',
        name: 'MoviesAPI',
        isFrench: false,
        urls: {
            movie: 'https://moviesapi.club/movie/{id}',
            tv:    'https://moviesapi.club/tv/{id}-{season}-{episode}'
        }
    },
    {
        id: 'mapple',
        name: 'MappleTv',
        isFrench: false,
        urls: {
            movie: 'https://mappletv.uk/watch/movie/{id}',
            tv:    'https://mappletv.uk/watch/tv/{id}-{season}-{episode}'
        }
    },
    {
        id: 'autoembed',
        name: 'AutoEmbed',
        isFrench: false,
        urls: {
            movie: 'https://player.autoembed.cc/embed/movie/{id}',
            tv:    'https://player.autoembed.cc/embed/tv/{id}/{season}/{episode}'
        }
    },
    {
        id: 'flicky',
        name: 'Flicky',
        isFrench: false,
        urls: {
            movie: 'https://flicky.host/embed/movie/?id={id}',
            tv:    'https://flicky.host/embed/tv/{id}/{season}/{episode}'
        }
    },
    {
        id: 'rive',
        name: 'RiveStream',
        isFrench: false,
        urls: {
            movie: 'https://rivestream.org/embed?type=movie&id={id}',
            tv:    'https://rivestream.org/embed?type=tv&id={id}&season={season}&episode={episode}'
        }
    },
    {
        id: 'vidora',
        name: 'Vidora',
        isFrench: false,
        urls: {
            movie: 'https://vidora.su/movie/{id}',
            tv:    'https://vidora.su/tv/{id}/{season}/{episode}'
        }
    },
    {
        id: 'nebula',
        name: 'NebulaFlix',
        isFrench: false,
        urls: {
            movie: 'https://nebulaflix.stream/movie?mt={id}&server=1',
            tv:    'https://nebulaflix.stream/show?st={id}&season={season}&episode={episode}&server=1'
        }
    },
    {
        id: 'smashystream',
        name: 'SmashyStream',
        isFrench: false,
        urls: {
            movie: 'https://player.smashy.stream/movie/{id}',
            tv:    'https://player.smashy.stream/tv/{id}?s={season}&e={episode}'
        }
    },
    {
        id: '2embed',
        name: '2Embed',
        isFrench: false,
        urls: {
            movie: 'https://www.2embed.cc/embed/{id}',
            tv:    'https://www.2embed.cc/embedtv/{id}&s={season}&e={episode}'
        }
    },
    {
        id: '123embed',
        name: '123Embed',
        isFrench: false,
        urls: {
            movie: 'https://play2.123embed.net/movie/{id}',
            tv:    'https://play2.123embed.net/tv/{id}/{season}/{episode}'
        }
    },
    {
        id: '111movies',
        name: '111Movies',
        isFrench: false,
        urls: {
            movie: 'https://111movies.com/movie/{id}',
            tv:    'https://111movies.com/tv/{id}/{season}/{episode}'
        }
    },
    {
        id: 'spenflix',
        name: 'Spenflix',
        isFrench: false,
        urls: {
            movie: 'https://spencerdevs.xyz/movie/{id}',
            tv:    'https://spencerdevs.xyz/tv/{id}/{season}/{episode}'
        }
    },
    {
        id: 'vidify',
        name: 'Vidify',
        isFrench: false,
        urls: {
            movie: 'https://vidify.top/embed/movie/{id}',
            tv:    'https://vidify.top/embed/tv/{id}/{season}/{episode}'
        }
    },
    {
        id: 'vidsrccx',
        name: 'VidSrcCX',
        isFrench: false,
        urls: {
            movie: 'https://vidsrc.cx/embed/movie/{id}',
            tv:    'https://vidsrc.cx/embed/tv/{id}/{season}/{episode}'
        }
    },
    {
        id: 'uembed',
        name: 'UEmbed',
        isFrench: false,
        urls: {
            movie: 'https://uembed.site/?id={id}',
            tv:    'https://uembed.site/?id={id}&season={season}&episode={episode}'
        }
    },
    // French sources — tested and ranked separately
    {
        id: 'frembed',
        name: 'Frembed',
        isFrench: true,
        urls: {
            movie: 'https://frembed.icu/api/film.php?id={id}',
            tv:    'https://frembed.icu/api/serie.php?id={id}&sa={season}&epi={episode}'
        }
    },
];

// The only entry shown in the UI.
// All 28+ sources above run silently behind this single label.
const availableSources = [
    {
        id:       'arcturusapi',
        name:     'Arcturus API',
        isFrench: false,
        _engine:  true,          // flag for watch.html to route through ArcturusEngine
        urls: {
            // Fallback URLs only — engine overrides these at runtime
            movie: 'https://vidfast.pro/movie/{id}',
            tv:    'https://vidfast.pro/tv/{id}/{season}/{episode}'
        }
    }
];
